/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dboard;

/**
 *
 * @author User
 */
public class Benefits implements Dashboard{

    @Override
    public void display() {
        System.out.print("PLEASE SHOW THE BENEFITS!");
    }
    
}
