/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dboard;
import javax.swing.plaf.synth.Region;
import login.AccReg;
/**
 *
 * @author User
 */
public class MySSReg {
    AccReg Reg = new AccReg();
    
}
