/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dboard;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class OnlineNum implements Dashboard{

    @Override
    public void display() {
        String FirstName, MiddleName, LastName, CivilStatus, BDay, Address, Age, PostalCode, SSNumber;
        Scanner input = new Scanner(System.in); 
        
        System.out.print("Input First Name: ");
        FirstName = input.nextLine();
        System.out.print("Input Middle Name: ");
        MiddleName = input.nextLine();
        System.out.print("Input Last Name: ");
        LastName = input.nextLine();
        System.out.print("Input Age: ");
        Age = input.nextLine();
        System.out.print("Input Birth Day format:(YYYY/MM/DD): ");
        BDay = input.nextLine();
        System.out.print("Input Complete Address: ");
        Address = input.nextLine();
        System.out.print("Input Postal Code: ");
        PostalCode = input.nextLine();
        System.out.print("Input SS number: ");
        SSNumber = input.nextLine();
        
    }
    
}
