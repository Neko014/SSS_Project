/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dboard;

import java.io.IOException;
import java.util.Scanner;
import login.AccLog;
import login.AccReg;
import OlNum.ApplyOnline;

/**
 *
 * @author User
 */
public class MainDashBoard {
    public void intro(){
        //Choice of Member or Register
       
        System.out.println("###################################################"); 
        System.out.println("#****   ##  REPUBLIC OF THE PHILIPINES   ##   ****#"); 
        System.out.println("#****   ##      SOCIAL                   ##   ****#"); 
        System.out.println("#****   ##            SECUTRITY          ##   ****#"); 
        System.out.println("#****   ##                     SYSTEM    ##   ****#"); 
        System.out.println("#****   ##  REPUBLIC OF THE PHILIPINES   ##   ****#"); 
        System.out.println("###################################################");
        System.out.println("");
        
        System.out.println("---------------------------------------------");
        System.out.println(" --- LIST OF SOCIAL SECURITY SERVICE---     ");
        System.out.println(" ● Member's Login                           ");
        System.out.println(" ● SSS Member's Registration                ");
        System.out.println(" ● Apply SSS Online Number                  ");
        System.out.println(" ● Benefits of Become SSS Member            ");
        System.out.println("----------------------------------------------");
        
        System.out.print("---> Choose (M) for Member, Choose (R) for Registration, Choose (A) to  Apply Online Number, And Choose (B) to See Benefits." +"\n"+ "---> :");
        
        
        
    }
    
    public void List () throws IOException, InterruptedException {
        
        
        
        Scanner sc = new Scanner(System.in);
        
        String choice = sc.nextLine();
        
        if(choice.equalsIgnoreCase("R")){
            AccReg reg = new AccReg();
            reg.register();
        } else if(choice.equalsIgnoreCase("A")) {
            ApplyOnline ol = new ApplyOnline();
            ol.OlNumber();
            
        }
        else if(choice.equalsIgnoreCase("B")) {
            Benefits B = new Benefits();
            B.display();
        } else if(choice.equalsIgnoreCase("M")) {
            AccLog log = new AccLog();
            log.login();
        }
        
    }
    
}
