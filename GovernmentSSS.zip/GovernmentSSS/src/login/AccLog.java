
package login;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import members.Member;

public class AccLog{
    Member mem = new Member();
    Scanner log = new Scanner(System.in);
    public String username, password;
    
     public void login() throws InterruptedException{
        System.out.println("\nMember's Login\n");
        System.out.print("Enter your username : ");
        username = log.nextLine();
        System.out.print("Enter your password : ");
        password = log.nextLine();
        
        Path path = Paths.get("UserAccounts\\" + username + "_" + password + ".txt");
            
        if(Files.notExists(path)){
            System.out.println("No Account Exist or Wrong Input.");
            login();
        }
        if(Files.exists(path)){
            System.out.println("Access Granted!");
            mem.display(username, password);
        }
    }
}
