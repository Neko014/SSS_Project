package login;

import dboard.MainDashBoard;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import static java.nio.file.StandardOpenOption.APPEND;
import java.util.Scanner;

//Done Register
public class AccReg{
    MainDashBoard MD = new MainDashBoard();
    Scanner input = new Scanner(System.in);
    private String username, password, passwordCheck;
    String FirstName, MiddleName, LastName, CivilStatus, BDay, Address, Age, PostalCode, SSNumber;
    
    FileWriter writer = null;
    
    public void register() throws IOException, InterruptedException{
        
        System.out.print("Register\n--------------------------------------------\nEnter your username: ");
        username = input.nextLine();
        inputPass();
            
    }
    public void inputPass() throws IOException, InterruptedException{
        System.out.print("\nEnter your password: ");
        password = input.nextLine();
        System.out.print("Confirm password: ");
        passwordCheck = input.nextLine();
        
        if(password.equals(passwordCheck)){// checks password
            // runs input info
            Credentials();
            // goes bakc to Selection and Intro
            MD.intro();
            MD.List();
        }
        else{
            System.out.print("\nPasswords do not match, Try Again. ");
            inputPass();
        }
    }
    public void Credentials(){
        System.out.print("Input First Name: ");
        FirstName = input.nextLine();
        System.out.print("Input Middle Name: ");
        MiddleName = input.nextLine();
        System.out.print("Input Last Name: ");
        LastName = input.nextLine();
        System.out.print("Input Age: ");
        Age = input.nextLine();
        System.out.print("Input Birth Day format:(YYYY/MM/DD): ");
        BDay = input.nextLine();
        System.out.print("Input Complete Address: ");
        Address = input.nextLine();
        System.out.print("Input Postal Code: ");
        PostalCode = input.nextLine();
        System.out.print("Input SS number: ");
        SSNumber = input.nextLine();
        
        System.out.print("Input Civil Status (1)Single (2)Married (3)Widowed: ");
        checkStatus();
        createTXT();
        
    }
    public void checkStatus(){
        char choose = input.next().toUpperCase().charAt(0);
        switch(choose){
            case '1':
                CivilStatus = "Single";
                break;
            case '2':
                CivilStatus = "Married";
                break;
            case '3':
                CivilStatus = "Widowed";
                break;
            default:
                System.out.println("Wrong Input choose between (1)(2)or(3).");
        }
    }
    public void createTXT(){
        try {
            //makes a balance txt file
            writer = new FileWriter("UsersBalance\\" + username + "_Balance.txt");
            
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("UserAccounts\\" + username + "_" + password + ".txt", true));
            
            bufferedWriter.write("Your Account: " + username + ", " + password);
            bufferedWriter.newLine();
            System.out.println("--------------------------------------------");
            bufferedWriter.close();
 
            // Defining the file name of the file
            Path path = Paths.get("UserAccounts\\" + username + "_" + password + ".txt");
            OutputStream output = new BufferedOutputStream(Files.newOutputStream(path, APPEND));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output));
            writer.write("Fullname: "+ LastName + ", " + FirstName + " " + MiddleName + "\n");
            writer.write("Civil Status: " + CivilStatus + "\n");
            writer.write("Birth Day: " + BDay + "\n");
            writer.write("Age: " + Age + "\n");
            writer.write("Address: " + Address + "\n");
            writer.write("SSNumber: " + SSNumber + "\n");
            writer.close();
            output.close();
            System.out.println("Account Made!");
            }
        catch (Exception e){
            System.out.println("Failed to create your Account!");
        }
    }
}