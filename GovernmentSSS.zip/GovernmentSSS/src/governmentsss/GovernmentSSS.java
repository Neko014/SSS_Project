
package governmentsss;
import java.io.IOException;
import dboard.MainDashBoard;

public class GovernmentSSS {

    
    public static void main(String[] args) throws IOException, InterruptedException {
         MainDashBoard MD = new MainDashBoard();
         
         MD.intro();
         MD.List();
    }
    
}
