
package members;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;

public class Member{
    Balance bal = new Balance();
    String Uname, Pass;
    
    public void display(String username, String password) throws InterruptedException{
        System.out.print("logging On");
        int i = 0;
        while(i < 3){
                Thread.sleep(1000);
                System.out.print(".");
                i++;
        }
        System.out.println(" Welcome back " +username+"!");
        Pass = password;
        Uname = username;
        viewAsk();
        viewBalance();
    }
    public void viewAsk(){//asks the user if they want to view their balance
        System.out.println("-----------------------------------");
        System.out.println("---> Balance                    (1)");
        System.out.println("---> Member Info                (2)");
        System.out.println("---> Exit                       (3)");
        System.out.println("-----------------------------------");
        System.out.print("---> ");
    }      
    public void viewBalance() throws InterruptedException{//asks the user if they want to view their balance
        Scanner input = new Scanner(System.in);
        switch(input.next().toUpperCase().charAt(0)){
            case '1':
                try{
                    System.out.println("UsersBalance\\" + Uname + "_Balance.txt");
                    BufferedReader gettingBal = new BufferedReader(new FileReader("UsersBalance\\" + Uname + "_Balance.txt"));
                    bal.getMoney(Integer.parseInt(gettingBal.readLine()));
                    bal.ShowBalance();
                }
                catch(Exception e){
                    System.out.println("Error No file found!");
                }
                System.out.println("Do you want to make a deposit? (Y) or (N):");
                System.out.print("--->: ");
                depositIN();
                viewAsk();
                viewBalance();
            break;
            case '2':
            {
                try {
                    BufferedReader gettingInfo = new BufferedReader(new FileReader("UserAccounts\\" + Uname + "_" + Pass + ".txt"));
                    String line = gettingInfo.readLine();
                    while(line != null){
                        System.out.println(line);
			// read next line
			line = gettingInfo.readLine();
                    }
                viewAsk();
                viewBalance();
                } 
                catch (Exception e) {
                    System.out.println("Error No file found!");
                }
            }
            break;
            case '3':
                System.out.print("logging Off");
                int i = 0;
                while(i < 3){
                    Thread.sleep(1000);
                    System.out.print(".");
                    i++;
                }
                System.out.println(" Have a nice day.");
            break;
            default:
                System.out.print("Wrong Input: ");
                viewBalance(); 
            break;
        }
    }
    public void depositIN() throws InterruptedException{
        Scanner input = new Scanner(System.in);
        switch(input.next().toUpperCase().charAt(0)){
            case 'Y':
                bal.BalanceDeposit(Uname);
                DepositAgain();
            break;
            case 'N':
                System.out.println("Selected No.");
            break;
            default:
                System.out.println("Wrong Input choose between (Y) or (N):");
                System.out.print("--->: ");
                depositIN(); 
            break;
        }
    }
    public void DepositAgain() throws InterruptedException{
        System.out.print("Do you want to deposit again? (Y) or (N):");
        depositIN();
    }
}