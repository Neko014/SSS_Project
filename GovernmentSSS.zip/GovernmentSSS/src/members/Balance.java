package members;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.Scanner;

public class Balance{
    Scanner input = new Scanner(System.in);
    private double money;
    DecimalFormat decimalFormat = new DecimalFormat("#.##");
    
    //Getting money from database
    public void getMoney(double SetMoney){
        money = SetMoney;
    }
    
    public void deposit(double addmoney){
        money = money + addmoney;
    }
    
    //Setting money to paste on print out
    public double setMoney(){
        return money;
    }
    
    public void ShowBalance(){
        // gets Value from setMoney and asks the user if they want to deposit money.
        decimalFormat.setGroupingUsed(true);
        decimalFormat.setGroupingSize(3);
        System.out.print("--------------------------------------------\n"
                          +"Your Current Balance is - " + decimalFormat.format(setMoney()) +"\n"
                          +"--------------------------------------------\n");
    }
    public void BalanceDeposit(String GetUser){
        //asks the user if they want to deposit money.
        System.out.print("Input Amount to be deposited:");
        deposit(input.nextDouble());
        System.out.print("--------------------------------------------\n"
                          +"Your Current Balance now is - " + decimalFormat.format(setMoney()) +"\n"
                          +"--------------------------------------------\n");
        try {
            System.out.println(GetUser);
            Path path = Paths.get("UsersBalance\\" + GetUser + "_Balance.txt");
            OutputStream output = new BufferedOutputStream(Files.newOutputStream(path));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output));
            writer.write(Double.toString(setMoney()));
            writer.close();
            output.close();
        } catch (IOException ex) {
            System.out.println("Failed to deposit Money!");
        }
    }
}
