
package OlNum;


public interface Restriction {
    public void RestrictSurname();
    public void RestrictGivenName();
    public void RestrictMiddleName();
    public void RestrictPostalCode();
    public void RestrictSexGender();
    public void RestrictDateOfBirth();
    public void RestrictCivilStatus();
    public void RestrictSpouseName();
}
