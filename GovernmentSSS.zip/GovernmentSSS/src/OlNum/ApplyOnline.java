
package OlNum;
import java.util.Scanner;

public class ApplyOnline {

  public void OlNumber () throws InterruptedException  {
      Scanner sc = new Scanner (System.in);
    //objects instantiated
        UserInput Repeat = new UserInput();
        UserInput Surname = new Surname();
        UserInput Question = new Question();
        UserInput GivenName = new GivenName();
        UserInput MiddleName = new MiddleName();
        UserInput Address = new Address();
        UserInput PostalCode = new PostalCode();
        UserInput SelectSexGender = new SelectSexGender();
        UserInput DateOfBirth = new DateOfBirth();
        UserInput CivilStatus = new CivilStatus();
        UserInput UserOutputPrintln = new UserOutputPrintln();
        UserInput SpouseName = new SpouseName();
        
 
        Restrict Restrict = new Restrict();
        
        System.out.println("-----------------------------------------------------PERSONAL RECORD-----------------------------------------------------");
        Thread.sleep(1000);
    //start of personal data questions
    //name start
        Surname.Print();//call print function from surname class
        GlobalVariables.SurnameVariable = sc.nextLine(); //call global variable for a name
        Restrict.RestrictSurname(); //implements interface restriction
        Question.Print();
    //switch loop for character restriction iterations of user input in yes or no     
            do {
                char UserChoice = GlobalVariables.YesNoVariable.toLowerCase().charAt(0);           
                switch (UserChoice) {
                    case 'y': //y for userchoice yes
                        GlobalVariables.Selection = false;
                    break;
                
                    case 'n': //n for userchoice no
                        GlobalVariables.Selection = true;
                        Repeat.Print(); //extends user input dialogue
                        Surname.Print();
                        GlobalVariables.SurnameVariable = sc.nextLine();
                        Restrict.RestrictSurname(); //implements interface restriction
                        Question.Print();
                    break;
                       
                    default: //any character input aside from y/n will result to default
                        System.out.println("Press 'Y' or 'N' only.");
                        Question.Print();
                    }         
            } while (GlobalVariables.Selection); //looping of question until boolean is false to proceed
    //Surname end
    
    GivenName.Print();//call print function from given name class
        GlobalVariables.GivenNameVariable = sc.nextLine(); //call global variable for a name
        Restrict.RestrictGivenName();
        Question.Print();
            do {
                char UserChoice = GlobalVariables.YesNoVariable.toLowerCase().charAt(0);           
                switch (UserChoice) {
                    case 'y': //y for userchoice yes
                        GlobalVariables.Selection = false;
                    break;
                
                    case 'n': //n for userchoice no
                        GlobalVariables.Selection = true;
                        Repeat.Print();
                        GivenName.Print();
                        GlobalVariables.GivenNameVariable = sc.nextLine();
                        Restrict.RestrictGivenName();
                        Question.Print();
                    break;
                       
                    default: //any character input aside from y/n will result to default
                        System.out.println("Press 'Y' or 'N' only.");
                        Question.Print();
                    }         
            } while (GlobalVariables.Selection); //looping of question until boolean is false to proceed
    //Given name end 
    
        MiddleName.Print();//call print function from middlename class
        GlobalVariables.MiddleNameVariable = sc.nextLine(); //call global variable for a name
        Restrict.RestrictMiddleName();
        Question.Print();
            do {
                char UserChoice = GlobalVariables.YesNoVariable.toLowerCase().charAt(0);           
                switch (UserChoice) {
                    case 'y': //y for userchoice yes
                        GlobalVariables.Selection = false;
                    break;
                
                    case 'n': //n for userchoice no
                        GlobalVariables.Selection = true;
                        Repeat.Print();
                        MiddleName.Print();
                        GlobalVariables.MiddleNameVariable = sc.nextLine();
                        Restrict.RestrictMiddleName();
                        Question.Print();
                    break;
                       
                    default: //any character input aside from y/n will result to default
                        System.out.println("Press 'Y' or 'N' only.");
                        Question.Print();
                    }         
            } while (GlobalVariables.Selection); //looping of question until boolean is false to proceed
    //Middle name end    

        Address.Print(); //call print function from address class
        GlobalVariables.AddressVariable = sc.nextLine(); //call global variable for address
        Question.Print();
            do {
                char UserChoice = GlobalVariables.YesNoVariable.toLowerCase().charAt(0);           
                switch (UserChoice) {
                    case 'y': //y for userchoice yes
                        GlobalVariables.Selection = false;
                    break;
                
                    case 'n': //n for userchoice no
                        GlobalVariables.Selection = true;
                        Repeat.Print();
                        Address.Print();
                        GlobalVariables.AddressVariable = sc.nextLine();
                        Question.Print();
                    break;
                       
                    default: //any character input aside from y/n will result to default
                        System.out.println("Press 'Y' or 'N' only.");
                        Question.Print();
                    }         
            } while (GlobalVariables.Selection); //looping of question until boolean is false to proceed
    //Address end      
                    
        PostalCode.Print(); //call print function from postal code class
        Restrict.RestrictPostalCode(); //4digit restriction interface
        Question.Print();
            do {
                char UserChoice = GlobalVariables.YesNoVariable.toLowerCase().charAt(0);           
                switch (UserChoice) {
                    case 'y': //y for userchoice yes
                        GlobalVariables.Selection = false;
                    break;
                
                    case 'n': //n for userchoice no
                        GlobalVariables.Selection = true;
                        Repeat.Print();
                        PostalCode.Print();
                        Restrict.RestrictPostalCode(); //4digit restriction interface
                        Question.Print();

                    break;
                       
                    default: //any character input aside from y/n will result to default
                        System.out.println("Press 'Y' or 'N' only.");
                        Question.Print();
                    }         
            } while (GlobalVariables.Selection); //looping of question until boolean is false to proceed
    //Postal Code end 
    
        SelectSexGender.Print();//call print function from Select sex gender class
        Restrict.RestrictSexGender(); //m or f character only restriction interface
        Question.Print();
            do {
                char UserChoice = GlobalVariables.YesNoVariable.toLowerCase().charAt(0);           
                switch (UserChoice) {
                    case 'y': //y for userchoice yes
                        GlobalVariables.Selection = false;
                    break;
                
                    case 'n': //n for userchoice no
                        GlobalVariables.Selection = true;
                        Repeat.Print();
                        SelectSexGender.Print();
                        Restrict.RestrictSexGender();
                        Question.Print();
                        
                    break;
                       
                    default: //any character input aside from y/n will result to default
                        System.out.println("Press 'Y' or 'N' only.");
                        Question.Print();
                    }         
            } while (GlobalVariables.Selection); //looping of question until boolean is false to proceed
    //Sex or gender end
    
        DateOfBirth.Print(); //call print function from date of birth class
        Restrict.RestrictDateOfBirth();//6digit restriction interface
        Question.Print();
            do {
                char UserChoice = GlobalVariables.YesNoVariable.toLowerCase().charAt(0);           
                switch (UserChoice) {
                    case 'y': //y for userchoice yes
                        GlobalVariables.Selection = false;
                    break;
                
                    case 'n': //n for userchoice no
                        GlobalVariables.Selection = true;
                        Repeat.Print();
                        DateOfBirth.Print();
                        Restrict.RestrictDateOfBirth();//4digit restriction interface
                        Question.Print();

                    break;
                       
                    default: //any character input aside from y/n will result to default
                        System.out.println("Press 'Y' or 'N' only.");
                        Question.Print();
                    }         
            } while (GlobalVariables.Selection); //looping of question until boolean is false to proceed
    //Date of birth end 

        CivilStatus.Print();//call print function from civil status class
        Restrict.RestrictCivilStatus();//s, m, w characters only restriction interface
        Question.Print();
            do {
                char UserChoice = GlobalVariables.YesNoVariable.toLowerCase().charAt(0);           
                switch (UserChoice) {
                    case 'y': //y for userchoice yes
                        GlobalVariables.Selection = false;
                    break;
                
                    case 'n': //n for userchoice no
                        GlobalVariables.Selection = true;
                        Repeat.Print();
                        CivilStatus.Print();
                        Restrict.RestrictCivilStatus();
                        Question.Print();
                        
                    break;
                       
                    default: //any character input aside from y/n will result to default
                        System.out.println("Press 'Y' or 'N' only.");
                        Question.Print();
                    }         
            } while (GlobalVariables.Selection); //looping of question until boolean is false to proceed
    //Sex or gender end    
//end of personal data record

//start of beneficiaries record
        SpouseName.Print();//call print function from spouse name class
        GlobalVariables.SpouseNameVariable = sc.nextLine(); //call global variable for a name
        Restrict.RestrictSpouseName();
        Question.Print();
            do {
                char UserChoice = GlobalVariables.YesNoVariable.toLowerCase().charAt(0);           
                switch (UserChoice) {
                    case 'y': //y for userchoice yes
                        GlobalVariables.Selection = false;
                    break;
                
                    case 'n': //n for userchoice no
                        GlobalVariables.Selection = true;
                        Repeat.Print();
                        SpouseName.Print();
                        GlobalVariables.SpouseNameVariable = sc.nextLine();
                        Restrict.RestrictSpouseName();
                        Question.Print();
                    break;
                       
                    default: //any character input aside from y/n will result to default
                        System.out.println("Press 'Y' or 'N' only.");
                        Question.Print();
                    }         
            } while (GlobalVariables.Selection); //looping of question until boolean is false to proceed
    //Middle name end
    Thread.sleep(900);
    System.out.println("-----------------------------------------------------BENEFICIARIES RECORD-----------------------------------------------------");
    System.out.println("Please enter 'NA' if not applicable.");
    Thread.sleep(1000);
    
//end of beneficiaries record

    UserOutputPrintln.Print(); //user's data output
  }
  
}

