package OlNum;

public class GlobalVariables { //global variable declarations
    //yes or no boolean variable
    public static boolean Selection = true;
    
    //personal record variables
    public static String YesNoVariable;
    public static String SurnameVariable;
    public static String GivenNameVariable;
    public static String MiddleNameVariable;
    public static String AddressVariable;
    public static String PostalCodeVariable;
    public static String SexGenderVariable;
    public static String DateOfBirthVariable;
    public static String CivilStatusVariable;
    public static int AgeVariable;
    
    //beneficiaries variables
    public static String SpouseNameVariable;
    public static String FatherNameVariable;
    public static String MotherNameVariable;    
    
    public static String FirstChildNameVariable;
    public static String SecondChildNameVariable;
    public static String ThirdChildNameVariable;
    public static String FourthChildNameVariable;
    public static String FifthChildNameVariable;
    
    public static String FirstChildBdayVariable;
    public static String SecondChildBdayVariable;
    public static String ThirdChildBdayVariable;
    public static String FourthChildBdayVariable;
    public static String FifthChildBdayVariable;
    
    //other beneficiaries variables
    public static String OtherOneVariable;
    public static String OtherTwoVariable;
    public static String OtherThreeVariable;
    public static String RelationshipOneVariable;
    public static String RelationshipTwoVariable;
    public static String RelationshipThreeVariable;    
}


