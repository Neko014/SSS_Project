
package OlNum;
import java.util.Scanner;

public class Restrict implements Restriction{

    @Override
    public void RestrictSurname() {
       UserInput Surname = new Surname(); //method body in a loop
        UserInput LettersOnly = new LettersOnly();
        Scanner sc = new Scanner(System.in);
                while(!GlobalVariables.SurnameVariable.matches("^[a-zA-Z ]+$")){ //restricts user input to match characters only
                LettersOnly.Print();
                Surname.Print();
                GlobalVariables.SurnameVariable = sc.nextLine();
                }
    }

     @Override //override annotation for static context
    public void RestrictGivenName(){ //character restriction function for given name
        UserInput GivenName = new GivenName(); //method body in a loop
        UserInput LettersOnly = new LettersOnly();
        Scanner sc = new Scanner(System.in);
                while(!GlobalVariables.GivenNameVariable.matches("^[a-zA-Z]+$")){ //restricts user input to match characters only
                LettersOnly.Print();
                GivenName.Print();
                GlobalVariables.GivenNameVariable = sc.nextLine();
                break;
                } 
    }   

    @Override //override annotation for static context
    public void RestrictMiddleName(){ //character restriction function for middle name
        UserInput MiddleName = new MiddleName(); //method body in a loop
        UserInput LettersOnly = new LettersOnly();
        Scanner sc = new Scanner(System.in);
                while(!GlobalVariables.MiddleNameVariable.matches("^[a-zA-Z]+$")){ //restricts user input to match characters only
                LettersOnly.Print();
                MiddleName.Print();
                GlobalVariables.MiddleNameVariable = sc.nextLine();
                break;
                } 
    }
    
    @Override //override annotation for static context
    public void RestrictPostalCode(){ // four digit restriction function for postal code 
        Scanner sc = new Scanner(System.in); //method body in a loop
        UserInput PostalCode = new PostalCode();
        UserInput FourDigitsOnly = new FourDigitsOnly();
        GlobalVariables.PostalCodeVariable = sc.nextLine();      
                while(!GlobalVariables.PostalCodeVariable.matches("^(\\d{4})")){ //restricts user input to match 4 digits only
                FourDigitsOnly.Print();
                PostalCode.Print();
                GlobalVariables.PostalCodeVariable = sc.nextLine();                                  
                }
    }
    @Override //override annotation for static context
    public void RestrictSexGender(){ //male or female(m/f) restriction function for sex or gender
        Scanner sc = new Scanner(System.in);//method body in a loop
        UserInput SelectSexGender = new SelectSexGender();
        UserInput MaleOrFemale = new MaleOrFemale();
        GlobalVariables.SexGenderVariable = sc.nextLine();                   
                while(!GlobalVariables.SexGenderVariable.matches("[mf]")){ //restricts user input to match one of the two characters only
                MaleOrFemale.Print();
                SelectSexGender.Print();
                GlobalVariables.SexGenderVariable = sc.nextLine();
                } 

                
    }
    
    @Override
    public void RestrictDateOfBirth(){ //digit restriction function for date of birth 
        Scanner sc = new Scanner(System.in); //method body in a loop
        UserInput DateOfBirth = new DateOfBirth();
        UserInput SixDigitsOnly = new SixDigitsOnly();
        GlobalVariables.DateOfBirthVariable = sc.nextLine();      
                while(!GlobalVariables.DateOfBirthVariable.matches("(\\d{4})-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])")){ //restricts user input to match 6 digits date format of birth format
                SixDigitsOnly.Print(); 
                DateOfBirth.Print();
                GlobalVariables.DateOfBirthVariable = sc.nextLine();                                  
                }    
    }
    
    @Override
    public void RestrictCivilStatus(){ //three letter restriction function for civil status
        Scanner sc = new Scanner(System.in); //method body in a loop
        UserInput CivilStatus = new CivilStatus();
        UserInput SingleMarriedWidowed = new SingleMarriedWidowed();
        GlobalVariables.CivilStatusVariable = sc.nextLine();                   
                while(!GlobalVariables.CivilStatusVariable.matches("[smw]")){ //restricts user input to match one of the two characters only
                SingleMarriedWidowed.Print();
                CivilStatus.Print();
                GlobalVariables.CivilStatusVariable = sc.nextLine();
                } 
    }
    
    @Override
    public void RestrictSpouseName(){ //character restriction function for spouse name
        UserInput SpouseName = new SpouseName(); //method body in a loop
        UserInput LettersOnly = new LettersOnly();
        Scanner sc = new Scanner(System.in);
                while(!GlobalVariables.SpouseNameVariable.matches("^[a-zA-Z]+$")){ //restricts user input to match characters only
                LettersOnly.Print();
                SpouseName.Print();
                GlobalVariables.SpouseNameVariable = sc.nextLine();
                } 
    }
}
