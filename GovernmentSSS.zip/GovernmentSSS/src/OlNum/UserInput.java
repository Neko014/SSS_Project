package OlNum;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;
//objects to perform different prints in a single action in different ways on the main method using polymorphism

public class UserInput {
    public void Print() {//repeat dialogue when user chooses no
        try{
        System.out.println("Please repeat.");
        Thread.sleep(900);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}

class LettersOnly extends UserInput{ 
    @Override
    public void Print(){
        try{
            System.out.println("Only characters are allowed, please repeat."); //character restriction dialogue
            Thread.sleep(900);            
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}

class NumbersOnly extends UserInput{ 
    @Override
    public void Print(){
        try{
            System.out.println("Only numbers are allowed, please repeat."); //number restriction dialogue
            Thread.sleep(900);            
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}

class FourDigitsOnly extends UserInput{ 
    @Override
    public void Print(){
        try{
            System.out.println("Only four(4)-digit number is allowed, please repeat."); //4 digit restriction dialogue
            Thread.sleep(900);            
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}

class SixDigitsOnly extends UserInput{ 
    @Override
    public void Print(){
        try{
            System.out.println("Please complete the Date Of Birth (ex. 1999-12-31)."); //6 digit restriction dialogue
            Thread.sleep(900);            
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}

class MaleOrFemale extends UserInput{
    public void Print(){
        try{
            System.out.println("Press 'M' for male or 'F' for female only.");
            Thread.sleep(900);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}

class SingleMarriedWidowed extends UserInput { // Civil status  dialogue user input
    @Override
    public void Print(){
        System.out.println("Press only one(1) letter ('S' - Single, 'M' - Married, 'W' - Widowed). Please Repeat. ");    
    }
}

class Question extends UserInput{ //question dialogue for yes or no user input
    @Override
    public void Print() { 
        Scanner YesNoInput = new Scanner(System.in);
        System.out.println("Is this correct? (Y/N)");
        GlobalVariables.YesNoVariable = YesNoInput.nextLine();
    }
}

class Surname extends UserInput { // Surname dialogue user input 
    @Override
    public void Print(){
        System.out.println("Enter your Surname: ");    
    }
}

class GivenName extends UserInput { // Given name dialogue user input
    @Override
    public void Print(){
        System.out.println("Enter your Given Name: ");    
    }
}

class MiddleName extends UserInput { // Middle name dialogue user input
    @Override
    public void Print(){
        System.out.println("Enter your Middle Name (Include the suffix if applicable ex: Jr, Sr, I): ");    
    }
}

class Address extends UserInput { // Address dialogue user input
    @Override
    public void Print(){
        System.out.println("Enter your Complete Address: (No. & Street ; City/Town & Province)");    
    }
}

class PostalCode extends UserInput { // Postal Code dialogue user input
    @Override
    public void Print(){
        System.out.println("Enter your 4-digit Postal Code: ");    
    }   
}

class SelectSexGender extends UserInput { // Sex or gender  dialogue user input
    @Override
    public void Print(){
        System.out.println("Select your Gender: (M/F) ");    
    }
}

class MaleOrFemalePrintln extends UserInput { //Gender print output
    @Override
    public void Print(){
        if(GlobalVariables.SexGenderVariable.equalsIgnoreCase("m")){
            System.out.println("     SEX: " + "MALE");
        }
        else {
            System.out.println("     SEX: " + "FEMALE");     
        }
    }
}

class DateOfBirth extends UserInput { // Address dialogue user input
    @Override
    public void Print(){
        System.out.println("Enter your Date of Birth (YYYY-MM-DD): ");    
    }   
}

class CivilStatus extends UserInput { // Civil status  dialogue user input
    @Override
    public void Print(){
        System.out.println("Enter your Civil Status (S for Single, M for Married, and W for Widowed): ");    
    }
}

///////////////////////////////////////////BENEFICIARIES
class SpouseName extends UserInput { // Spouse name dialogue user input 
    @Override
    public void Print(){
        System.out.println("Enter your Spouse's name: ");    
    }
}

class FatherName extends UserInput { // Father name dialogue user input 
    @Override
    public void Print(){
        System.out.println("Enter your Father's name: ");    
    }
}

class MotherName extends UserInput { // Mother name dialogue user input 
    @Override
    public void Print(){
        System.out.println("Enter your Mother's name: ");    
    }
}

class FirstChildName extends UserInput { // First child name dialogue user input 
    @Override
    public void Print(){
        System.out.println("Enter your First Child's name: ");    
    }
}

class SecondChildName extends UserInput { // Second child name dialogue user input 
    @Override
    public void Print(){
        System.out.println("Enter your Second Child's name: ");    
    }
}

class ThirdChildName extends UserInput { // Third child name dialogue user input 
    @Override
    public void Print(){
        System.out.println("Enter your Third Child's name: ");    
    }
}

class FourthChildName extends UserInput { // Fourth name dialogue user input 
    @Override
    public void Print(){
        System.out.println("Enter your Fourth Child's name: ");    
    }
}

class FifthChildName extends UserInput { // Fifth name dialogue user input 
    @Override
    public void Print(){
        System.out.println("Enter your Fifth Child's name: ");    
    }
}
class UserOutputPrintln extends UserInput { //Date of birth and age output
    @Override
    public void Print(){
        System.out.println("*****************************************************PERSONAL RECORD*****************************************************");
        System.out.println("     FULL NAME: " + GlobalVariables.SurnameVariable.toUpperCase() + ", " + GlobalVariables.GivenNameVariable.toUpperCase() + " " + GlobalVariables.MiddleNameVariable.toUpperCase());
        System.out.println("     ADDRESS: "+ GlobalVariables.AddressVariable.toUpperCase() + " " + GlobalVariables.PostalCodeVariable);
        
        //if else function for gender output
        if(GlobalVariables.SexGenderVariable.equalsIgnoreCase("m")){
            System.out.println("     SEX: " + "MALE");
        }
        else {
            System.out.println("     SEX: " + "FEMALE");     
        }
        //age computation function output
        LocalDate Today = LocalDate.now();
        LocalDate Bday = LocalDate.parse(GlobalVariables.DateOfBirthVariable);
        GlobalVariables.AgeVariable = Period.between(Bday, Today).getYears();
        System.out.println("     AGE: " + GlobalVariables.AgeVariable);
        
        System.out.println("     DATE OF BIRTH: " + GlobalVariables.DateOfBirthVariable);
        
        //if else-if else function for civil status output
        if(GlobalVariables.CivilStatusVariable.equalsIgnoreCase("s")){
            System.out.println("     CIVIL STATUS: " + "SINGLE");
        }
        else if(GlobalVariables.CivilStatusVariable.equalsIgnoreCase("m")){
            System.out.println("     CIVIL STATUS: " + "MARRIED");     
        }
        else {
            System.out.println("     CIVIL STATUS: " + "WIDOWED");
        }
        
        System.out.println("******************************************************BENEFICIARIES******************************************************");
    }
}